// =========================================
// Part 1:Mastering Javascript Basics
// =========================================

//  Variable & Conditionals
let userAge = prompt("Enter your age: ");
userAge = Number(userAge);

if (userAge >= 18) {
  console.log("✅ You are an adult.");
} else {
  console.log("❌ You are not an adult yet.");
}

// ===============================
// Part 2: Funtions
// ===============================

// Function 1: Addition function
function calculateSum(a, b) {
  return a + b;
}
console.log("Sum of 3 and 7: ", calculateSum(3, 7));

// Function 2: Toggling a text Content
function toggleName() {
  const nameHeading = document.getElementById("my-name");
  if (nameHeading.textContent === "Mazalee") {
    nameHeading.textContent = "Aikhuegbe Daniel";
    nameHeading.style.color = "blue";
  } else {
    nameHeading.textContent = "Mazalee";
    nameHeading.style.color = "white";
  }
}

// =====================
// Part 3: Loops
// =====================

// First Loop: add 4 list items
for (let i = 1; i <= 5; i++) {
  let li = document.createElement("li");
  li.textContent = "List Item " + i;
  document.getElementById("list").appendChild(li);
}

// Second loop: countdown
let countdown = 5;
while (countdown > 0) {
  console.log("Countdown:", countdown);
  countdown--;
}

// ===============================
// Part 4: DOM Manipulation
// ===============================

// DOM 1: Add new item when button clicked
document.getElementById("add").addEventListener("click", function () {
  const li = document.createElement("li");
  li.textContent = "New Item";
  document.getElementById("list").appendChild(li);
});

// DOM 2: Show alert when button clicked
document.getElementById("alert").addEventListener("click", function () {
  alert("Hello! This is your alert");
});

// DOM 1: Toggle name is click
document.getElementById("my-name").addEventListener("click", toggleName);
